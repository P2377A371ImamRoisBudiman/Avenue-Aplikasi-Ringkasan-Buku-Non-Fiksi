package com.example.avenue

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
