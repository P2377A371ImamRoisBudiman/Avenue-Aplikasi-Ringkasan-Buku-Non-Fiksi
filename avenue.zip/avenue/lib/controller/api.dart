class ApiConstant{
  String baseUrl = "http://192.168.1./ebookapp/";
  String api = "api.php?";
  String slide = "slider";
  String latest = "latest";
}