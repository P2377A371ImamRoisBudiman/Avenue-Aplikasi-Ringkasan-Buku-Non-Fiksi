class ApiConstant {
  String baseUrl = "http://192.168.111.144/ebookapp/";
  String api = "api.php?";
  String slide = "slider";
  String latest = "latest";
  String coming = "coming";
  String category = "category";
  String register = "utils/register.php";
}
