import 'package:flutter/cupertino.dart';

class avenueFavorite extends StatefulWidget {
  const avenueFavorite({Key? key}) : super(key: key);

  @override
  State<avenueFavorite> createState() => _avenueFavoriteState();
}

class _avenueFavoriteState extends State<avenueFavorite> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
