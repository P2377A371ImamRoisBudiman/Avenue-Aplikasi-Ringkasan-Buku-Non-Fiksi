import 'package:flutter/cupertino.dart';

class EbookAccount extends StatefulWidget {
  const EbookAccount({Key? key}) : super(key: key);

  @override
  State<EbookAccount> createState() => _EbookAccountState();
}

class _EbookAccountState extends State<EbookAccount> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
