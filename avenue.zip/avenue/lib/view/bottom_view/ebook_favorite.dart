import 'package:flutter/cupertino.dart';

class EbookFavorite extends StatefulWidget {
  const EbookFavorite({Key? key}) : super(key: key);

  @override
  State<EbookFavorite> createState() => _EbookFavoriteState();
}

class _EbookFavoriteState extends State<EbookFavorite> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
