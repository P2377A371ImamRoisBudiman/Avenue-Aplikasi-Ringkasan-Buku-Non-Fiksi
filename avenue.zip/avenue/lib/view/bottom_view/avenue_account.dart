import 'package:flutter/cupertino.dart';

class avenueAccount extends StatefulWidget {
  const avenueAccount({Key? key}) : super(key: key);

  @override
  State<avenueAccount> createState() => _avenueAccountState();
}

class _avenueAccountState extends State<avenueAccount> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
