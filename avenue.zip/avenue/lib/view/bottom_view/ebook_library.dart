import 'package:flutter/cupertino.dart';

class EbookLibrary extends StatefulWidget {
  const EbookLibrary({Key? key}) : super(key: key);

  @override
  State<EbookLibrary> createState() => _EbookLibraryState();
}

class _EbookLibraryState extends State<EbookLibrary> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
